import 'package:flutter/material.dart';

class GlobalConfig {
  static ThemeData themeData = new ThemeData.dark();
}